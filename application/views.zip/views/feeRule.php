<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
    <div class="contentPane">
      <div class="contentPaneLt">
      <div class="inHeadimg">
      	<img src="<?php echo base_url();?>assets/images/admission.jpg" alt="">
        <h3>We encourage those students who are ready to take up challenges</h3>
      </div>
        <div class="cont_lt_col1">
          <div class="breadcrumb"><a href="index-2.html" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Admissions</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Fee Rule</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title">   <h2>Fee Rule</h2></div>                           <div class="intContent">                                                    <h3>RULES REGARDING FEES</h3>             <p> <strong>1-</strong>
 Monthly fee will be deposited from 1st to 15th each month.<br>

<strong>2-</strong> In case fee is not deposited during the stipulated period a late fee Rs 5/- perday will be charged.<br>

<strong>3-</strong> If the fee is not paid for 2 months,then re-admission charge along with monthly fee will be charged.<br>

<strong>4-</strong> Fee for the month of May will be deposited with that of Jan,and for the month of June with that of Feb,every year.<br>

<strong>5-</strong> Annual fee will be charged in the month of April every year.<br>

<strong>6-</strong> Fee once deposited will not be refunded in any case.


          
                                </p>                                                   </div></div>
        </div>
        
      </div>
      
      <?php $this->load->view("sidebar4");?>
      
    </div>
  </div>
   <?php $this->load->view("footer");?>