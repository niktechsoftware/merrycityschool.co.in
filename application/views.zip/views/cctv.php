 <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/cctv.jpg" alt="">
<h3>Providing the best of Play Ground Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Play Ground Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Our schools are where our children should feel safe. It is where they learn about themselves and the world around them. Sadly, if our past few years are any indication, schools are not the safe places we thought they were, and anything can happen when certain circumstances facilitate a tragic situation.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;However, there are things that can be done to prevent that from happening, and to keep schools as the safe places they are supposed to be. It comes in the form of surveillance systems. These systems, which include CCTV security cameras, DVRs, and remote viewing capabilities are changing the way parents, and teachers see the school.<br>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; While we talk about using surveillance systems to keep schools safe, we are not just talking about school shootings. We are also talking about a parent's ability to watch their children from afar, with remote viewing, to ensure they are safe as well.<br>



                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>