  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/computerlab.jpg" alt="">
<h3>Providing the best of Play Ground Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Play Ground Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       
Merry City School has large lab to teach Computer.
Using individual computers in the classroom often falls under the category of blended learning. This style of learning is when instructors incorporate several methods for delivering content to students. Some teachers use computers with special needs students as tools to help overcome communication issues. Computers may be used to help share assignments, engage in various activities, provide real-time communication experiences with others regardless the distance, enhance or expand lessons and increase knowledge. Mobile computing is becoming a popular mode of learning and schools are embracing technology outside of the computer lab and in the classroom.



                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>