  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/playground.jpg" alt="">
<h3>Providing the best of Play Ground Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Play Ground Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       

Play is the key to physical, mental, intellectual and social well being of children. It impacts hugely on almost every developmental aspect of children's lives holistically and with multifaceted ways. Young children spend a reasonable amount of time in school. Besides, for many children, school play time is the most active part of their day. Therefore, school playground and school playtime are vitally important to children for their fun and relaxation as well as for their good health and well-being. School playgrounds play important role in their daily life for fulfilling their interest, development and learning needs.



                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>