<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane">
      <div class="contentPaneLt">
        <div class="cont_lt_col1">
          <div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/aboutus_txt.jpg" alt="">
            
          </div>
          <div class="breadcrumb"><a href="<?php echo base_url();?>" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">School</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> About us</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2> About Merry City School</h2></div> <div class="intContent"><span style="font-weight: bold;">Merry City School, Ghazipur</span> is the creation of some ambitious person with noble through to serve the nation through education . Merry City School started its journey in 1985 Mau Nath Bhanjan with 100 students reaching the strength of 2000 students. In 1997, Merry City School, Varanasi was launched to serve the society with 200 students but recently it is running with full capacity. On this side Merry City School, Ghazipur is going to launch a unique academic by bleding the mordern world and the traditional society so that it becomes a pioneering institution in varanasi.<br>
               &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; At Merry City School, every child placed in our care is precious and we aim to provide the best possible environment for the child to grow in a secure, safe habitat where they may weave their dreams and grow.<br>
          The philosophy of the school is based upon the Statement of Purpose, which provides the fountainhead from which our students’ dreams take flight, for it combines a strong belief in service with compassion and an underlying awareness of the greatness of our own culture.<br>
          Situated as we are in a lush green campus with first class teaching facilities, we are fortunate to have a talented and dedicated team of educators, along with a single-mindedly committed support staff who make sure that our learning environment is the best. It is in this ambience that our students imbibe their education.
            </div></div>
        </div>
      </div>
    <?php $this->load->view("pageSideBar");?>
    </div>
    <!--Content Pane--> 
  </div>
<?php $this->load->view("footer");?>