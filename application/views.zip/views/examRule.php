<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
    <div class="contentPane">
      <div class="contentPaneLt">
      <div class="inHeadimg">
      	<img src="<?php echo base_url();?>assets/images/admission.jpg" alt="">
        <h3>We encourage those students who are ready to take up challenges</h3>
      </div>
        <div class="cont_lt_col1">
          <div class="breadcrumb"><a href="index-2.html" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Admissions</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Examination Rule</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title">   <h2>Fee Rule</h2></div>                           <div class="intContent">                                                    <h3>RULES REGARDING Examination</h3>             <p> <strong>1-</strong>
There will be two Assessments  </p>

<strong>(a) Summative Assessment-</strong> I Will likelyto be held in the month of october and.<br>

<strong>(b) Summative Assessment-</strong> II will be held in the month of March every year.<br>
<p>
<strong>2-</strong>  Besides (a) and (b) there will be held 4 formative assessment every year.


          
                                </p>                                                   </div></div>
        </div>
        
      </div>
      
      <?php $this->load->view("sidebar4");?>
      
    </div>
  </div>
   <?php $this->load->view("footer");?>