 <footer class="footer1">
    <div class="wrapper">
      <div class="footerPanel">
        <div class="footCol">
          <font size="3" color="white">Quick Links</font>
          <ul class="fooNavList">
            <!--<li><a href="circulars.aspx" title="Circulars">Circulars</a></li>-->
            <li><a href="<?php echo base_url();?>index.php/welcome/gallery" title="Photo Gallery" class="noBg"><font size="2" color="white">Photo Gallery</font></a></li>
            <li><a href="#" title="Academic Information"><font size="2" color="white">Academic Information</font></a></li>
            <li><a href="#" target="_blank"  title="Upcoming Events" ><font size="2" color="white">Upcoming Events</font></a></li>
          </ul>
        </div>
        <div class="footCol">
          <font size="3" color="white">School</font>
          <ul class="fooNavList">
            <li><a href="#" title="Our Founder"><font size="2" color="white">Our Founder</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/aboutUs" title="About us" class="noBg"><font size="2" color="white">About us</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/vision" title="Vision"><font size="2" color="white">Vision</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/objective" title="Objective"><font size="2" color="white">Objective</font></a></li>
            
            <li><a href="#" title="Affiliation"><font size="2" color="white">Affiliation</font></a></li>
            <!--<li><a href="#" title="Alumni Registration">Alumni Registration</a></li>-->
            <li><a href="#" title="Our Founder"><font size="2" color="white">Our Founder</font></a></li>
          </ul>
         
        
        </div>
        <div class="footCol">
          <font size="3" color="white">Facilities</font>
          <ul class="fooNavList">
            <li><a href="<?php echo base_url();?>index.php/welcome/medical" title="Medical Facilities" class="noBg"><font size="2" color="white">Medical Facilities</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/transpotation" title="Transportation"><font size="2" color="white">Transportation</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/classRoom" title="Classrooms"><font size="2" color="white">Classrooms</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/playGround" title="Computer Lab"><font size="2" color="white">Play Ground</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/computerLab" title="Library"><font size="2" color="white">Computer Lab</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/library" title="Library"><font size="2" color="white">Library</font></a></li>
             <li><a href="<?php echo base_url();?>index.php/welcome/cctv" title="Library"><font size="2" color="white">CCTV Camera</font></a></li>
          </ul>
        </div>
        <div class="footCol">
         <font size="3" color="white">Admissions</font>
          <ul class="fooNavList">
            <li><a href="<?php echo base_url();?>index.php/welcome/generalRule" title="Admissions" class="noBg"><font size="2" color="white">Admissions Rules</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/parentsRule" title="Application Procedure"><font size="2" color="white">Application Procedure</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/feeRule" title="Fee Structure"><font size="2" color="white">Fee Structure</font></a></li>
            <li><a href="#" title="Online Application Form"><font size="2" color="white">Online Application Form</font></a></li>
            <!--<li><a href="#" title="Online Brochure">Online Brochure</a></li>-->
          </ul>
          </ul>
        </div>
        <div class="footCol">
          <font size="3" color="white">Messages</font>
          <ul class="fooNavList">
            <li><a href="<?php echo base_url();?>index.php/welcome/Cmessage" title="Message from Chairman" class="noBg"><font size="2" color="white">Message from Chairman</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/Mmessage" title="Message from Director"><font size="2" color="white">Message from Manager</font></a></li>
            <!--<li><a href="#" title="Message from Secretary">Message from Secretary</a></li>-->
            <li><a href="<?php echo base_url();?>index.php/welcome/Pmessage" title="Message from Principal"><font size="2" color="white">Message from Principal</font></a></li>
          </ul>
          <h3>Co-curricular Activities</h3>
          <ul class="fooNavList">
            <li><a href="<?php echo base_url();?>index.php/welcome/mdt" title="Music Dance &amp; Theatre" class="noBg"><font size="2" color="white">Music Dance &amp; Theatre</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/aircraft" title="Art &amp; Craft"><font size="2" color="white">Art &amp; Craft</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/sportYoga" title="Sports &amp; Yoga"><font size="2" color="white">Sports &amp; Yoga</font></a></li>
            <li><a href="<?php echo base_url();?>index.php/welcome/perDev" title="Personality Development"><font size="2" color="white">Personality Development</font></a></li>
             <li><a href="<?php echo base_url();?>index.php/welcome/HouseActivity" title="Personality Development"><font size="2" color="white">House Activities</font></a></li>
          </ul>
        </div>
        <div class="fooRw2">
          <div class="frw2Lt">
            <ul class="botNav">
              <li><a href="#" title="Home" class="noBg"><font size="2" color="white">Home</font></a></li>
              <li><a href="#" title="Visits"><font size="2" color="white">Visits</font></a></li>
              <li><a href="#" title="Annual Calendar"><font size="2" color="white">Annual Calendar</font></a></li>
              <li><a href="#" title="Photo Gallery"><font size="2" color="white">Photo Gallery</font></a></li>
              <li><a href="#" title="Health Care"><font size="2" color="white">Health Care</font></a></li>
            
              <li><a href="#" title="Sitemap"><font size="2" color="white">Sitemap</font></a></li>
              <li><a href="#" title="Contact Us"><font size="2" color="white">Contact Us</font></a></li>
            </ul>
            <div class="copyright"><font size="2" color="white"> @ 2017 Merry City School All rights reserved.</font> </div>
          </div>
          <div class="socialIcon"> <a href="#" title="FaceBook" target="_blank"><img src="<?php echo base_url();?>assets/images/fbIcon.png" alt="" />
          </a> <a href="#" title="Twitter" target="_blank"><img src="<?php echo base_url();?>assets/images/twitterIcon.png" alt="" />
          </a> <a href="#" title="LinkedIn" target="_blank"><img src="<?php echo base_url();?>assets/images/linkedin.png" alt="" /></a> </div>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </footer>

 


<!--<script src="http://code.jquery.com/jquery-1.8.3.min.js"></script>--> 
<script src="<?php echo base_url();?>assets/js/classie.js"></script> 
<script src="<?php echo base_url();?>assets/js/gnmenu.js"></script> 
<script src="<?php echo base_url();?>assets/gallery/js/jquery-1.11.0.min.js"></script>
	<script src="<?php echo base_url();?>assets/gallery/js/lightbox.js"></script>
<script>
new gnMenu( document.getElementById( 'gn-menu' ) );

	$(document).ready(function(){
    $('.toggler').on('click',function(){
      //$(this).parent().children().toggle();  //swaps the display:none between the two spans
      $(this).parent().find('.toggled_content').slideToggle();  //swap the display of the main content with slide action

  	});
	
	 $('.toggler').on('click',function(){
      //$(this).parent().children().toggle();  //swaps the display:none between the two spans
      $(this).parent().find('.fa-angle-right').toggleClass("arrow_rotate");  //swap the display of the main content with slide action

  	});
    
	});
</script>

</body>
</html>
