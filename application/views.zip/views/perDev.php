  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/pdclass.jpg" alt="">
<h3>Providing the best of Play Ground Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Play Ground Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       
The concern of any parent today is how to make their children realise their dreams in life. The race for a good education starts the day the child turns two years and does not end till the child enters the college. With the Indian economy becoming global year after year, the competition to secure a seat in the best schools has become even more severe. With parents attaching more and more importance to quality education and with the middle class boom, investment on a school project is becoming a popular decision. This has resulted in proliferation of schools.
<p>
The child's intelligence is, of course, an important determinant of what he is able to learn. Teachers can, with psychological training, learn to work with children in such a way as to modify their faulty concepts of self. Advocates of the view that the school should educate the whole child, on the other hand, are likely to stress the role of the school as a means of socializing the child and of fostering the mental health and personality adjustment necessary to enable him to take his place as a responsible citizen in a democratic society. Good teachers appear to concern themselves with the non-intellectual as well as with the intellectual development of children, even if they believe the school should limit its objectives to intellectual development. In particular, the principles underlying the acquisition of the self-concept and the level of aspiration can be effectively applied in motivating children to learn in the classroom.

</p>




                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>