  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/commingsoon.jpg" alt="">
<h3>Message from Chairman</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Message</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Message from Chairman</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Message From Chairman</h2></div>                         <div class="intContent">                       





                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>