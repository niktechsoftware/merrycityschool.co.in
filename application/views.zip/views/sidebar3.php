 <div class="rightPane">
        
        <div class="rightPane_mid">
          <div class="intsidebar">
            <h2>Messages</h2>
            <div class="intlinkList leftNav">
              <ul>
                <li><a href="<?php echo base_url();?>index.php/welcome/Cmessage" title="Message from Chairman">Message from Chairman</a></li>
                <li><a href="<?php echo base_url();?>index.php/welcome/Mmessage" title="Message from Director">Message from Manager</a></li>
                <!--<li><a href="<?php echo base_url();?>index.php/welcome/Pmessage" title="Message from Secretary">Message from Secretary</a></li>-->
                <li><a href="<?php echo base_url();?>index.php/welcome/Pmessage" title="Message from Principal" class="selected">Message from Principal</a></li>
              </ul>
            </div>
          </div>
          <!-- <div class="rightPaneRw2"> <a href="#" class="try" title=""> <img src="images/sibeBanner.png" alt="" /></a> </div>-->
        </div>
        
      </div>