<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/transportation.jpg" alt="">
<h3>Providing the best of Transportation Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Transportation Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Transportation Facilities</h2></div>                         <div class="intContent">                       Merry City School has many air-conditioned buses running to and fro the city and neighboring places like Barabanki. The bus routes are designed such that students do not have any problem in commuting from their homes to the school. Luxury mini buses pick up the students from their doorsteps and drop them to the major bus stops. The school is well connected to Ghazipur city through various other means of public transport also.                         </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>