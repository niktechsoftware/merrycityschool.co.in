<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane">
      <div class="contentPaneLt">
        <div class="cont_lt_col1">
          <div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Messages</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Message from Principal</div>
          <div class="int-title">
            <h2>Message from Principal</h2>
          </div>
          <div class="intContent">
            <div id="ctl00_ContentPlaceHolder1_visitText"><p><img complete="complete" src="<?php echo base_url();?>assets/images/principal1.jpg" />It has been an eventful journey for the school since we started from the scrath and slowly become a force to reckon with, for which I offer my sincere thanks to all the honourable members of the managing committee, the staff and the parents of our students whose good will cooperation have gone a long way in making our endeavour a sucess.In keeping with the changing times, where the world is becoming more competitive with every passing day and posing new challenges for the younger generation, we aim at providing holistic, child-centered education . we have strived towards excellence in all spheres aiming at the all round development of the child. Each your has been a step towards acheiving further panache in moulding a child in to a confident and accoplished indivisual abreased to modern times, yet endowed with the age-old value of honesty, benevelolence, helpful and the importance of conducting himself with elan and dignity. It therefore become imperative to ignite a spark in the mind of the child to awaken the will in the students to acquire more knowledge which in turm would lend them clarity of throught and bring out the best in them.</p>
            <h4 style="color:red;">"I hope, my institution will be able to nurture and mound your child to help him realise his potential to the fullest and live upto your expectations."</h4>
             <p align="right"><span class="membername">Mr.Ajit Rai</span> <br />   <i>Principal</i><br />   <br /> </p></div>
          </div>
        </div>
        
      </div>
       <?php $this->load->view("sidebar3");?>
    </div>
  </div>

  <?php $this->load->view("footer");?>