 <div class="rightPane">
        <div class="rightPane_mid">
          <div class="intsidebar">
            <h2>Admissions</h2>
            <div class="intlinkList leftNav">
              <ul>
                <li><a href="<?php echo base_url();?>index.php/welcome/generalRule" title="Admissions" >General Rule</a></li>
                <li><a href="<?php echo base_url();?>index.php/welcome/parentsRule" title="Prents Rule" class="selected">Prents Rule</a></li>
                <li><a href="<?php echo base_url();?>index.php/welcome/feeRule" title="Fee Structure">Fee Rule</a></li>
                 <li><a href="<?php echo base_url();?>index.php/welcome/uniformRule" title="Fee Structure">Uniform Rule</a></li>
                 <li><a href="<?php echo base_url();?>index.php/welcome/examRule" title="Fee Structure">Examination Rule</a></li>
                <li><a href="#" title="Online Application Form">Online Application Form</a></li>
                <!--<li><a href="online-brochure.aspx" title="Online Brochure">Online Brochure</a></li>-->
              </ul>
            </div>
          </div>
          <!-- <div class="rightPaneRw2"> <a href="#" class="try" title=""> <img src="images/sibeBanner.png" alt="" /></a> </div>--> 
        </div>
      </div>