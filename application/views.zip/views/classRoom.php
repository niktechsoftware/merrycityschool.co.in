<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/classroom.jpg" alt="">
<h3>Providing the best of Class Room Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Class Room Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Class Room Facilities</h2></div>                         <div class="intContent">                       Merry City School believes that for students to put in their best efforts in academics an ideal studying environment is a must. Hence, we have fully air conditioned classrooms which enables the students to concentrate fully and at the same time be able to enjoy the comforts of home.    
<p>
Responsive Classroom is an evidence-based approach to elementary and middle school teaching that focuses on the strong link between academic success and social-emotional learning (SEL). We believe that a high-quality education for every child is built on the foundation of a safe and joyful learning community. We provide professional development for elementary and middle schools worldwide.

</p>                    </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>