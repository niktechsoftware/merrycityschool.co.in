<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane">
      <div class="contentPaneLt">
        <div class="cont_lt_col1">
          <div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/vision_txt.jpg" alt="">
            
          </div>
          <div class="breadcrumb"><a href="<?php echo base_url();?>" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">School</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Vision</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2> About Merry City School</h2></div> <div class="intContent"><span style="font-weight: bold;"></span>
          <ul>
            <li>The institute that stand out is established through people have ideas, thoughts, creativity and above all vision.</li>
              <li>The behind this institute have a vision to createMerry City School, Ghazipur a vibrant learning organization in the field of education. </li>
              <li>Our Mission is to provide a vibrant forum for quality education, with a scientific temper,adaptive to the changing needs of time, to ensure all round development of the child and expose him/her to a wide spectrum of co-cultural learning which is essential to make the child confident and ready to step out in today’s challenging world</li>
              <li>We enable a lifelong pursuit of learning by creating meaning, developing habits of mind, and acting on values</li>
              <li> We provide learning in a safe, nurturing, enjoyable, culturally fruitful and stimulating environment. We enable imaginative thinking</li>
              <li>We enable ourselves to be open to risk, change, and innovation. We enable students, faculty, and start to become confident and responsible leaders.</li>
              <li>We take pride in Guru Shishya Parampara balancing traditional human values of integrity and humility with the best global practices.</li>
             
          </ul>
          
            </div></div>
        </div>
      </div>
    <?php $this->load->view("pageSideBar");?>
    </div>
    <!--Content Pane--> 
  </div>
<?php $this->load->view("footer");?>