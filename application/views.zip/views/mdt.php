  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/mdt.jpg" alt="">
<h3>Music Dance and Theater</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span>  Music Theatre and Dance</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       

Students at Merry City School are always encouraged to explore their potential in the world of the Arts. The students are trained to play various Indian and Western musical instruments and are also taught Indian & Western Vocal Music.
<p>
The School of Theatre and Dance at Merry City School provides in-depth artistic and technical training on a liberal arts . The school’s professional culture permeates every facet of life and learning, allowing students to cultivate their talents and make the connections necessary for career success. Year-round production opportunities provide students with a quality education in our state-of-the-art facilities, including the recently completed Roe Green Center for the School of Theatre and Dance which houses more than 70,000 square feet of learning, performance, and design space. With three performance spaces on site in the Center for the Performing Arts and a fourth in the form of our outdoor summer theatre, Porthouse Theatre, students have frequent chances to display their work.
</p>



                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>