<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
    <div class="contentPane">
      <div class="contentPaneLt">
      <div class="inHeadimg">
      	<img src="<?php echo base_url();?>assets/images/admission.jpg" alt="">
        <h3>We encourage those students who are ready to take up challenges</h3>
      </div>
        <div class="cont_lt_col1">
          <div class="breadcrumb"><a href="index-2.html" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Admissions</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Fee Rule</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title">   <h2>Uniform Rule</h2></div>                           <div class="intContent">                                                    <h3>School Uniform</h3>           <span class="membername" style="color:red;">For Boys:</span><br />   White Shirt with tie collar Steel Grey Pant With Belt. <br />
           <span class="membername"style="color:red;">For Girls:</span><br />  White Blouse with tie collar. Steel Grey tunic. <br /> 
             
           <span class="membername"style="color:red;">Boys and girls : </span> <br />   (1) Belt <br /> (2) Black Socks and black Shoes. <br /> (3) I-Card  <br />                                     
            <span class="membername"style="color:red;">During winter : </span><br />
            <strong> Boys - </strong> Full Shirt and Pant. <br />
            <strong>  Girls - </strong> Full Blouse.<br />
            Nevi Blue full sleeve sweater up to class 2nd Nevi Blue Blazer + half sleeve sweater are compulsory Class IIIrd on wards.<br />
            <span class="membername"style="color:red;">Wednesday + Saturday : </span><br />
            <strong> Boys - </strong>  House T-shirt+white pant, white shoes+white socks. <br />
            <strong>  Girls - </strong> White skirt+houset-shirt, white shoes+white socks .<br />
            Parents/Guardian are requested to sent their children to the school neatly dressed in clean uniform daily. 
            </div></div>
        </div>
        
      </div>
      
      <?php $this->load->view("sidebar4");?>
      
    </div>
  </div>
   <?php $this->load->view("footer");?>