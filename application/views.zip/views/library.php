  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/schoollibrary.jpg" alt="">
<h3>Providing the best of Play Ground Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Play Ground Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       

The school library is central to learning and plays a key role as a place for encouraging innovation, curiosity, and problem solving. Your library is a catalyst for literacy and reading and for teaching and scaffolding inquiry learning. School libraries make a difference to students' understanding and achievement and provide support for teaching and learning throughout the school. The school library is an important part of the school community and reflects and welcomes this community.

Our school library plays a key role in the cultural and social life of the school. It can be a central point for engagement with all kinds of reading, cultural activities, access to information, knowledge building, deep thinking and lively discussion.



                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>