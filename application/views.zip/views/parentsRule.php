<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
    <div class="contentPane">
      <div class="contentPaneLt">
      <div class="inHeadimg">
      	<img src="<?php echo base_url();?>assets/images/admission.jpg" alt="">
        <h3>We encourage those students who are ready to take up challenges</h3>
      </div>
        <div class="cont_lt_col1">
          <div class="breadcrumb"><a href="index-2.html" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Admissions</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Parents Rule</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title">   <h2>Application Procedure</h2></div>                           <div class="intContent">                                                    <h3>Rules For The Parents/Gaurdians </h3>             <p> <strong>1-</strong>school is not responsible for loss of any personal contly things brought by students.<br>

<strong>2-</strong> All the books,work-books and note books must be convered with brown paper and lableled.<br>

<strong>3-</strong> Parents are requested to see the school diary daily and put signature send necessary notices.<br>

<strong>4-</strong> Please,send water bottle and tiffin daily.<br>

<strong>5-</strong> School will work up to half day on last working day of every month.<br>

<strong>6-</strong> parents will not be allowed to enter the class during school time without permission of the principal.<br>

<strong>7-</strong> Students must come prepared with the lesson taught and home work completed.<br>

<strong>8-</strong> Parents/Guardian are accepted to co-operate with the class teacher for satisfactory progress of their children.<br>


          
                                </p>                                                   </div></div>
        </div>
        
      </div>
      
      <?php $this->load->view("sidebar4");?>
      
    </div>
  </div>
   <?php $this->load->view("footer");?>