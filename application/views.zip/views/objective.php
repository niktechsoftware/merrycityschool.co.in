<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane">
      <div class="contentPaneLt">
        <div class="cont_lt_col1">
          <div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/objective_txt.jpg" alt="">
            
          </div>
          <div class="breadcrumb"><a href="<?php echo base_url();?>" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">School</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Objective</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2> About Merry City School</h2></div> <div class="intContent"><span style="font-weight: bold;"></span>
          <ul><li>The institute that stand out is established through people have ideas, thoughts, creativity and above all vision.</li>
          <li>The behind this institute have a vision to createMerry City School, Ghazipur a vibrant learning organization in the field of education.</li>
          <li>To train the alumni to meet the challenges of latest educational world.</li>
            <li>To develop attitute and skills for all round development of presently.</li>
              <li>To inculcate a sence of academic excellence and expertise in communication skills. </li>
              <li>Prepare students to be independent thinkers, skillful communicators, and lifelong learners and global citizens</li>
              <li>By nurturing an atmosphere of trust between students, staff, administrators and parents</li>
              <li>By providing a wide variety of stimulating learning experiences, allowing students to acquire the concepts, skills and attitudes necessary to develop their full individual potential</li>
          </ul>
          
            </div></div>
        </div>
      </div>
    <?php $this->load->view("pageSideBar");?>
    </div>
    <!--Content Pane--> 
  </div>
<?php $this->load->view("footer");?>