<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane">
      <div class="contentPaneLt">
        <div class="cont_lt_col1">
          <div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Messages</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Message from Manager</div>
          <div class="int-title">
            <h2>Message from Principal</h2>
          </div>
          <div class="intContent">
            <div id="ctl00_ContentPlaceHolder1_visitText"><p><img complete="complete" src="<?php echo base_url();?>assets/images/manager.jpg" />Education in the emerging global knowledge economy has become a great leveler amongst Individuals and Nations, being the highest form of organizational capital. The whole purpose of education is for all individuals to learn and grow as better people, everyone in this sector, should then make an effort to work together to achieve the common goal. The need of the hour is to help our children become independent thinkers and develop integrated personalities. In parallel with this thought we at City International School always believe that education should create the pupil's life as a whole in terms of positive attitude towards life, decision making skills, learning about the world around them, and of all a good Human Being... so as where ever our CITYites go, they will put themselves at a concrete level in the society... As per the theme of our magazine i.e, 'Environment' I would profoundly like to put in the quote of Charles Darwin</p>
            <h4 style="color:red;">"It is not the strongest species that survives But the one most responsive and the fittest to the environment"</h4>
             <p align="right"><span class="membername">-----------</span> <br />   <i>Manager</i><br />   <br /> </p></div>
          </div>
        </div>
        
      </div>
       <?php $this->load->view("sidebar3");?>
    </div>
  </div>

  <?php $this->load->view("footer");?>