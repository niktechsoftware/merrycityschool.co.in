
  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/medi_student_b.jpg" alt="">
<h3>Providing the best of Medical Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Medical Facilities</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Medical Facilities</h2></div>                         <div class="intContent">                       The school shows its utmost concern for its students by providing the best of medical facilities. <br /> <br />Merry City School has standing arrangements for emergency medical aid with reputed hospitals in the vicinity. Our students and faculty form the backbone of the school and to ensure their sound health conditions, medical checkups are conducted from time to time. All the students are medically insured to cover all the ailments according to the general insurance norms.                         </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>