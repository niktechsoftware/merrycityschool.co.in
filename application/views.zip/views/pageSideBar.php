  <div class="rightPane">
        <div class="rightPane_mid">
          <div class="intsidebar">
            <h2>School</h2>
            <div class="intlinkList leftNav">
              <ul>
                <li><a href="#" title="Our Founder">Our Founder</a></li>
                <li><a href="<?php echo base_url();?>index.php/welcome/aboutUs" title="About us" class="selected">About us</a></li>
                <li><a href="<?php echo base_url();?>index.php/welcome/vision" title="Vision">Vision</a></li>
                <li><a href="<?php echo base_url();?>index.php/welcome/objective" title="Objective">Objective</a></li>
                
                <li><a href="#" title="Affiliation" >Affiliation</a></li>
              </ul>
            </div>
          </div>
          <!-- <div class="rightPaneRw2"> <a href="#" class="try" title="Highlights of Annual Functions"> <img src="images/sibeBanner.png" alt="" /></a> </div>--> 
        </div>
      </div>