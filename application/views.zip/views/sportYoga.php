  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/yoga.jpg" alt="">
<h3>Providing the best of Sports And Yoga Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Sports And Yoga</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       

Merry City lays great stress on the physical development of children. Half an hour in the morning is set apart for P.T./Yoga for which there are specialist teachers. The tradition of 'Yoga' initiated by the ancient rishis is followed in Merry City to perpetuate the 'sanskaras' of our ancestors. These sessions which focus on the spiritual and health aspects help the students to improve their academic skills as well. Excellence in sports activities also gets enhanced due to Yoga techniques. Improved immunity and concentration accelerate the performance.
<p>

As yoga becomes more popular in schools through physical education classes and after-school programs, that popularity comes with controversy. Although many adults like the benefits of yoga, some parents feel that the practice might have a religious association and, like prayer, shouldn't be allowed in a public space. They argue that yoga is an offshoot of Hinduism and that it disseminates religious and meditation principles with its use of "om" and "namaste" chanting. Some also believe that the asanas, or postures, such as the sun salutation, are a form of Hindu religious worship. To dispel this notion and avoid any religious or cultural messages, most yoga teachers focus on the benefits of the exercises and use generic terms, instead of the Sanskrit names, for the poses, renaming them cat, bridge, table, tree, downward-facing dog, volcano, and so forth. Yoga's rising popularity can be attributed to its basic stretching advantages and improved body awareness, with the added component of a mind-body connection.
</p>



                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>