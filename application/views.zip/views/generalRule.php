<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
    <div class="contentPane">
      <div class="contentPaneLt">
      <div class="inHeadimg">
      	<img src="<?php echo base_url();?>assets/images/admission.jpg" alt="">
        <h3>We encourage those students who are ready to take up challenges</h3>
      </div>
        <div class="cont_lt_col1">
          <div class="breadcrumb"><a href="index-2.html" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Admissions</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> General Rule</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title">   <h2>Application Procedure</h2></div>                           <div class="intContent">                                                    <h3>General Rule</h3>             <p> <strong>1-</strong> Admission in all the class is likely to be completed within the period commencing from April 5 to May 15, every year.<br>

<strong>2- </strong>Admission and detentioin of pupils in the school will be subject to the approval of the principal.<br>

<strong>3-</strong> Admission si subject to qualifying the admissin test by the candidate.<br>

<strong>4-</strong> Regularity with punctuality is the accepted requirement of the school.<br>

<strong>5-</strong> Children have to come to the school neatly dressed in school uniform.<br>

<strong>6-</strong> No student will be admitted without transfer certificate and marksheet from the last school,if he/she has attended.<br>

<strong>7-</strong> Leave will not be granted without a leave application,who will be absent without application for leave more than 10 days his/her name may be struck off the rolls as a rule may be re-admitted.<br>

<strong>8- </strong>75% attendance is compulsory for promotion to higher classes.


          
                                </p>                                                   </div></div>
        </div>
        
      </div>
      
      <?php $this->load->view("sidebar4");?>
      
    </div>
  </div>
   <?php $this->load->view("footer");?>