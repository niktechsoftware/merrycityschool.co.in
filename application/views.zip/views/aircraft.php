  <?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
<div class="wrapper">
<div class="contentPane">
<div class="contentPaneLt">
<div class="cont_lt_col1">
<div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/artcraft.jpg" alt="">
<h3>Providing the best of Art and Craft work Facilities</h3>
</div>
<div class="breadcrumb"><a href="#" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">Facilities</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Art and Craft work</div>
<div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2>Play Ground Facilities</h2></div>                         <div class="intContent">                       

Students at Merry City School is always laid on Art and Craft work and it is an integral part of the school curriculum. Students are taught to draw, paint and create unique craft work using different mediums, materials and techniques.
<p>
Arts and crafts for kids are fun for children and the young-at-heart! These art & craft activities cover a wide range of subjects for young artists, future artisanal book makers, potential puppeteers, and more. These aren't just arts and crafts for kids; they're fun for the whole family too! Our selection of art projects for kids, DIY activities, and decoration ideas also provide excellent inspiration for craft ideas for kids. Try some of these activities with your children, and have fun with crafts for kids to make.

</p>




                       </div></div>
</div>
</div>
 <?php $this->load->view("sidebar2");?>
</div>
</div>

  <?php $this->load->view("footer");?>