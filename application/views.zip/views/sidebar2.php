<div class="rightPane">
<div class="rightPane_mid">
<div class="intsidebar">
<h2>Facilities</h2>
<div class="intlinkList leftNav">
<ul>
<li><a href="<?php echo base_url();?>index.php/welcome/medical" title="Medical Facilities" class="selected">Medical Facilities</a></li>
<li><a href="<?php echo base_url();?>index.php/welcome/transpotation" title="Transportation">Transportation</a></li>
<li><a href="<?php echo base_url();?>index.php/welcome/classRoom" title="Classrooms">Classrooms</a></li>
<li><a href="<?php echo base_url();?>index.php/welcome/playground" title="Computer Lab">Play Ground</a></li>
<li><a href="<?php echo base_url();?>index.php/welcome/computerLab" title="Computer Lab">Computer Lab</a></li>
<li><a href="<?php echo base_url();?>index.php/welcome/library" title="Library">Library</a></li>
<li><a href="<?php echo base_url();?>index.php/welcome/cctv" title="Swimming Pool">CCTV Camra</a></li>
</ul>
</div>
</div>
<!--<div class="rightPaneRw2"> <a href="#" class="try" title=""> <img src="images/sibeBanner.png" alt="" /></a> </div>-->
</div>
</div>